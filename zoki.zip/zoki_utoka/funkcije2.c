#include <stdio.h>

int prestupne(int);

int main(){
	int a=0;
	int b=2018;

	for(a;a<=2018;a++){
		if(prestupne(a)){
			printf("Prestupna god je %d\n", a);
		}
	}
	return 0;
}

int prestupne(int x){
	return (x%4 == 0) && (x%100 !=0 || x%400 ==0);
}
