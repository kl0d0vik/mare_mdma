
#include <stdio.h>
#include <stdlib.h>

typedef char Tizraz30[31];

int main(){

	FILE *IZLdat;
	Tizraz30 ime, prezime, NazivIZLdat="ime.txt";
	printf("Unesite vase ime : ");
	scanf("%s", &ime);
	__fpurge(stdin);
	printf("Unesite vase prezime : ");
	scanf("%s", &prezime);
	__fpurge(stdin);
	//printf("Unesite naziv datoteke u koju zelite da unesete podatke: ");
	//scanf("%s", NazivIZLdat);
	if((IZLdat = fopen(NazivIZLdat,"a"))==NULL){
		printf("Greska prilikom otvaranja %s",NazivIZLdat);
		exit(EXIT_FAILURE);
	}
	fprintf(IZLdat,"\n%s\t%s\n",ime,prezime);
	fclose(IZLdat);
	printf("\n Podaci upisani u %s ", NazivIZLdat);
}
