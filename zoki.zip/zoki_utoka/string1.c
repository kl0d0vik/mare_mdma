#include <stdio.h>
#include <string.h>


int ispis(char *);

int main(){

	char str[20];
	printf("Unesi string ");
	scanf("%s", &str);

	ispis(str);

}

int ispis(char *str){
	int i,n;

	n = strlen(str);

	for(i=n-1;i>=0;i--){
		printf("%c\n",str[i]);
	}


}
