#include <stdio.h>

int main(){

	int i;
	int n = 5;
	int fib = 0;

	for(i=0;i<n;i++){
		fib += i;
	}

	printf("%d\n",fib);



}
