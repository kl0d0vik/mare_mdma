#include <stdio.h>
#define MAX_SIZE 30

int main(){

	int niz[MAX_SIZE];
	int i,j=0,n,br;

	for(i=0;i<MAX_SIZE;i++){
		niz[i] = 0;
	}
	printf("ukucaj broj clanova niza: ");
	scanf("%d",&n);
	printf("ukucaj broj br: ");
	scanf("%d", &br);

	for(i=0;i<n;i++){
		printf("niz[%d] : ",i);
		scanf("%d", &niz[i]);
	}

	for(i=0;i<n;i++){
		printf("niz[%d] = %d\n",i,niz[i]);
		if(niz[i] == br){
			j++;
		}
	}

	printf("broj br - %d se pojavljuje %d puta\n",br,j);
	return 0;

}
