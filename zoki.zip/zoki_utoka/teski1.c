#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAX_SIZE 2048

int prebroj(char *);
int max(char *);
int ispis(int n,char *, char *);



int main(int brArg, char *arg[]){

	char f1ime[MAX_SIZE],f2ime[MAX_SIZE];
	if(brArg!=3){
		printf("program [ulazna-datoteka] [izlazna-datoteka]\n");
		exit(1);
	}

	strcpy(f1ime,arg[1]);
	strcpy(f2ime,arg[2]);

	prebroj(f1ime);


}

int prebroj(char *f1ime){

	FILE *pf;
	char str[MAX_SIZE];
	char str2[MAX_SIZE];
	pf = fopen(f1ime, "r");

	if(pf!=NULL){
		while(fgets(str,MAX_SIZE,pf)!=NULL){
			strcat(str2,strtok(str,"\n"));
		}
	}
	printf("%s\n", str2);
}
