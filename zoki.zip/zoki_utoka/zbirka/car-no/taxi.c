#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#define MAX_OZNAKA 2+1
#define MAX_KARAKTER 20
#define MAX_SIZE 30

struct taxi_st{
	char oznaka[MAX_OZNAKA];
	char naziv_udruzenja[MAX_KARAKTER];
	unsigned cena_starta;
	unsigned cena_po_km;
};

struct cena_st{
	char oznaka[MAX_OZNAKA];
	char naziv_udruzenja[MAX_KARAKTER];
	double cena_prevoza;

};

FILE *safe_fopen(char filename[], char mode[], int error_code);
void ucitaj(FILE *in, struct taxi_st taxi[], int *n);
void transform(struct taxi_st taxi[], struct cena_st cena[], int n, float kilometri);
void ispisi(FILE *out, struct cena_st cena[], int n);


int main(int brArg, char **args){

	if(brArg!=4){
		printf("Pusi kurac ne valja\n");
	}
	float kilometri = atoi(args[1]);
	char *input_filename = args[2];
	char *output_filename = args[3];

	FILE *in = safe_fopen(input_filename, "r", 1);
	FILE *out = safe_fopen(output_filename, "w",2);

	struct taxi_st taxi[MAX_SIZE];
	struct cena_st cena[MAX_SIZE];
	int n;

	ucitaj(in, taxi, &n);
	transform(taxi, cena, n, kilometri);
	ispisi(out, cena, n);

	fclose(in);
	fclose(out);

}


FILE *safe_fopen(char filename[], char mode[], int error_code){
	FILE *fp = fopen(filename, mode);
	if(fp==NULL){
		printf("Nema fajla ili slicno\n");
		exit(error_code);
	}
}
void ucitaj(FILE *in, struct taxi_st taxi[], int *n){
	*n=0;
	while(fscanf(in,"%s %s %u %u",
		taxi[*n].oznaka,
		taxi[*n].naziv_udruzenja,
		&taxi[*n].cena_starta,
		&taxi[*n].cena_po_km
	)!=EOF){
		(*n)++;
	}
}

void transform(struct taxi_st taxi[], struct cena_st cena[], int n, float kilometri){
	int i;
	for(i=0;i<n;i++){
		strcpy(cena[i].oznaka, taxi[i].oznaka);
		strcpy(cena[i].naziv_udruzenja, taxi[i].naziv_udruzenja);
		cena[i].cena_prevoza = taxi[i].cena_starta + taxi[i].cena_po_km*kilometri;
	}
}
void ispisi(FILE *out, struct cena_st cena[], int n){
	int i;
	for(i=0;i<n;i++){
		fprintf(out,"%s %s %4.0lf\n", cena[i].oznaka, cena[i].naziv_udruzenja, cena[i].cena_prevoza);
	}
}

















