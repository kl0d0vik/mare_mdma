#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

#define MAX_SIZE 30
#define MAX_CHAR 20

struct pacijent_st{
	char ime[MAX_CHAR];
	char prezime[MAX_CHAR];
	unsigned masa;
	double visina;
};

struct analiza_st{
	char ime[MAX_CHAR];
	char prezime[MAX_CHAR];
	double bmi;
	char dijagnoza[MAX_CHAR];
};

FILE *safe_fopen(char filename[], char mode[],int error_code);
void ucitaj(FILE *in, struct pacijent_st pacijenti[],int *n);
void transform(struct pacijent_st pacijenti[], struct analiza_st analiza[], int n);
void snimi_analize(FILE *out, struct analiza_st analize[], int n);

int main(int brArg, char **arg){

	if(brArg<3){
		printf("usage %s input output\n",arg[0]);
	}

	char *input_filename = arg[1];
	char *output_filename = arg[2];

	FILE *in = safe_fopen(input_filename, "r", 1);
	FILE *out = safe_fopen(output_filename, "w", 2);

	struct pacijent_st pacijenti[MAX_SIZE];
	struct analiza_st analiza[MAX_SIZE];
	int n;


	ucitaj(in, pacijenti, &n);
	transform(pacijenti, analiza, n);
	snimi_analize(out, analiza, n);

	fclose(in);
	fclose(out);
	return 0;
}

FILE *safe_fopen(char filename[], char mode[], int error_code){
	FILE *fn = fopen(filename,mode);
	if(fn==NULL){
		printf("Ne moze se otvoriti %s \n",filename);
		exit(error_code);
	}
	return fn;
}

void ucitaj(FILE *in, struct pacijent_st pacijenti[], int *n){
	*n = 0;
	while(fscanf(in, "%s %s %u %lf",
		pacijenti[*n].ime,
		pacijenti[*n].prezime,
		&pacijenti[*n].masa,
		&pacijenti[*n].visina
	) != EOF){
		(*n)++;
	}
}

void transform(struct pacijent_st pacijenti[], struct analiza_st analiza[], int n){
	int i;
	for(i=0;i<n;i++){
		strcpy(analiza[i].ime, pacijenti[i].ime);
		strcpy(analiza[i].prezime, pacijenti[i].prezime);
		analiza[i].bmi = pacijenti[i].masa/(pacijenti[i].visina*pacijenti[i].visina);

		if(analiza[i].bmi<18.5){
			strcpy(analiza[i].dijagnoza, "Pothranjen");
		}
		else if(analiza[i].bmi<25.0){
			strcpy(analiza[i].dijagnoza, "Idealno");
		}
		else if(analiza[i].bmi<30.0){
			strcpy(analiza[i].dijagnoza, "Debelesina");
		}
		else{
			strcpy(analiza[i].dijagnoza, "Gojaznost");
		}
	}
}

void snimi_analize(FILE *out, struct analiza_st analize[], int n){
	int i;
	for(i=0;i<n;i++){
		fprintf(
			out," %s %s %.2f %s\n",
			analize[i].ime,
            		analize[i].prezime,
            		analize[i].bmi,
            		analize[i].dijagnoza
        	);
    }
}
