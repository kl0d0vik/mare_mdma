#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_SIZE 20+1
#define MAX 30


struct paket_st{
	char provajder[MAX_SIZE];
	char naziv_paketa[MAX_SIZE];
	int pretplata;
	int br_besplatnih;
	float cena_po_poruci;
};

struct cena_st{
	double ukupna_cena;
	char provajder[MAX_SIZE];
	char naziv_paketa[MAX_SIZE];
};


FILE *safe_fopen(char filename[], char mode[], int error_code);
void ucitaj_podatke(FILE *in, struct paket_st paketi[], int *n);


int main(int brArg, char *arg[]){

	if(brArg < 4){
		printf("USAGE: %s broj_poruka paketi.txt cene.txt\n",arg[0]);
	}

	char in_filename = arg[2];
	char out_filename = arg[3];
	int n;

	struct paket_st paketi[MAX];
	struct cena_st cena[MAX];

	FILE *in = safe_fopen(in_filename, "r", 1);
	FILE *out = safe_fopen(out_filename, "w", 1);

	ucitaj_podatke(in, paketi,  &n);


}

FILE *safe_fopen(char filename[], char mode[], int error_code){
		FILE *input_file = fopen(filename, mode);
		if(input_file==NULL){
			printf("Nemoguce otvoriti %s\n", filename);
			exit(error_code);
		}
		return input_file;
}

//void ucitaj_podatke(FILE *in, struct paket_st paketi[],*n){
//	*n = 0;
//	while(fscanf(in, "%s %s %d %d %lf", paketi[*n].provajder, paketi[*n].naziv_paketa, &paketi[*n].pretplata, &paketi[*n].br_besplatnih, &paketi[*n].cena_po_poruci)!=EOF){
//		(*n)++;
//	}
//}

void ucitaj_podatke(FILE *in, struct paket_st paketi[], int *n) {
    *n = 0;
    while(fscanf(
        in, "%s %s %d %d %lf",
         paketi[*n].provajder,
         paketi[*n].naziv_paketa,
        &paketi[*n].pretplata,
        &paketi[*n].br_besplatnih,
        &paketi[*n].cena_po_poruci
    ) != EOF) {
        (*n)++;
    }
}



























