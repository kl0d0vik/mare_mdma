#include <stdio.h>

int check(int);
int fakt(int);

int main(){
	int i;
	for(i=100;i<=999;i++){
		if(check(i)){
			printf("Broj %d ", i);
		}
		else{
			continue;
		}
	}

}

int check(int a){
	return (a == fakt(a/100)+fakt((a%100)/10)+fakt(a%10));
	}


int fakt(int a){
	int fakt = 1;
	for(a;a>0;a--){
		fakt *=a;
	}
}
