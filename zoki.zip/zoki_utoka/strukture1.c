#include <stdio.h>

struct tacka {
	float x;
	float y;
};

void ispis(struct tacka t);

int main(){

	struct tacka t1, t2;

	printf("Unesite X i Y koordinatu tacke 1: ");
	scanf("%f %f", &t1.x, &t1.y);

	printf("Unesite X i Y koordinatu tacke 2: ");
	scanf("%f %f", &t2.x, &t2.y);

	ispis(t1);
	ispis(t2);

	return 0;

}

void ispis(struct tacka t){
	printf("\n ( %.2f, %.2f)\n", t.x, t.y);

}
