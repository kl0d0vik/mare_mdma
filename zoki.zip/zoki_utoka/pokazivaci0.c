#include <stdio.h>

int main(){

	int a = 5;
	int b, c;
	int *p1, *p2;

	p1 = &a;
	p2 = &b;

	printf("%p\n",p1);
	printf("%p\n",&a);
	printf("%d\n",&a);
	printf("%d\n",*p1);

	// pokazivaci se prave sa * a uzimaju vr neke varijable sa &varijabla
	//  %p - printuj adresu bajo moj

}
