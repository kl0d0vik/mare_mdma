#include <stdio.h>
#define MAX_SIZE 20

int main(){

	int niz[MAX_SIZE];
	int n,i,max=0;

	for(i=0;i<MAX_SIZE;i++){
		niz[i] = 0;
	}

	printf("unesi klk clanova niza : ");
	scanf("%d", &n);

	for(i=0;i<n;i++){
		printf("niz[%d]=",i);
		scanf("%d", &niz[i]);
	}

	for(i=0;i<n;i++){
		if(niz[i] > max){
			max = niz[i];
		}
		else{
			continue;
		}
	}
	printf("Max je %d", max);
	return 0;

}
