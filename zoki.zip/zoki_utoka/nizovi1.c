#include <stdio.h>
#define MAX_SIZE 30


int main() {

	int niz[MAX_SIZE];
	int n,i;

	for(i=0;i<MAX_SIZE;i++){
		niz[i] = 0;
	}

	printf("Koliki niz zelite: ");
	scanf("%d",&n);

	for(i=0;i<n;i++){
		printf("niz[%d] = ",i);
		scanf("%d", &niz[i]);
	}
	for(i=0;i<n;i++){
		printf("%d",niz[i]);
	}
	printf("\n");
	for(i = n-1; i>=0; i--){
		printf("%d", niz[i]);
	}
	printf("\n");

	return 0;

}
