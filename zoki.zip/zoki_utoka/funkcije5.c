#include <stdio.h>

int prost(int);


int main(){


	int n=12,m,j;
	//int a = prost(7);
	//printf("%d\n",a);
	for(m=1;m<n;m++){
		//printf("m=%d\n",m);
		for(j=m;j<n;j++){
		//	printf("j=%d\n",j);
			if(prost(m) + prost(j) == n){
				printf("%d je zbir %d i %d\n", n,m,j);
				break;
			}
			else{
				continue;
			}
		
		}
	}





}

int prost(int x){

	if(x==1 || x==2 || x==3){
		return x;
	}
        else{
		int i;
        	for(i=2;i<=x-1;i++){
                	if(x%i == 0){
                        	break;
                        	return x;
                	}
                	else{
                        	continue;
                	}
        	}

	}
}

