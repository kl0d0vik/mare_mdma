#include <stdio.h>
#define MAX_SIZE 5

int main(){

	char niz[MAX_SIZE];
	int i,b;

	for(i=0;i<MAX_SIZE;i++){
		printf("niz[%d] = ",i);
		scanf(" %c", &niz[i]);
	}

	b = 'a';
	printf("%d",b);

}


// ima na githubu a i uostalom znam
