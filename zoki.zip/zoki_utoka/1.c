#include <stdio.h>

int main(){

	int i,m;

	for(i=0;i<100;i++){
		printf("i\n");
		for(m=0;m<100;m++){
			printf("m\n");
		}
	}

}
