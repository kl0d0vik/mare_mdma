#include <stdio.h>

int fakt(int);


int main(){

	int m = fakt(5);
	printf("%d\n",m);


}

int fakt(int n){

	if(n<2){
		return 1;
	}
	else{
		return n * fakt(n-1);
	}
}
