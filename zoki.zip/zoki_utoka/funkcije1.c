#include <stdio.h>
#include <math.h>

int hipotenuza(int a, int b);

int main(){

	float c;

	c =hipotenuza(3,4);
	printf("%lf", c);


}
int hipotenuza(int a, int b){
	return sqrt(a*a+b*b);
}



	
