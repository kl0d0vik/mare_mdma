#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_SIZE 256

void kodiraj(char *, char *);
void dekodiraj(char *, char *);


int main(){

//	kodiraj("abcd.txt", "AAAAA");
	dekodiraj("AAAA","abcd.txt");

}

void kodiraj(char *ul_dat, char *izl_dat){

	int i;
	FILE *u,*n;
	char str[256];
	u = fopen(ul_dat, "r");
	n = fopen(izl_dat, "w");

	if(u!=NULL){
		while(fgets(str,256,u)!=NULL){
			for(i=0;i<strlen(str);i++){
				if((str[i]>=65 && str[i]<90 )||( str[i]>=97 && str[i]<122)){
					str[i] = str[i] + 1;
				}
				else if(str[i] == 90){
					str[i] = 65;
				}
				else if(str[i] == 122){
					str[i] = 97;
				}
				else{
					continue;
				}
			}
		}

	}
	if(n!=NULL){
		fprintf(n,"%s",str);
	}

}
void dekodiraj(
// naopako samo ulazi i -1 je 
//nemam snage

