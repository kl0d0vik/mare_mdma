#include <stdio.h>
#include <string.h>
#define MAXL 512

int main(){

	FILE *pf;
	char str[MAXL];

	pf = fopen("abcd.txt", "r");

	if(pf!=NULL){
		while(fgets(str, MAXL, pf)!=NULL){
			puts(strtok(str,"\n"));
		}


		fclose(pf);
	}
	else{
		printf("No file or impossible to open\n");
	}

}
