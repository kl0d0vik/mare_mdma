#include <stdio.h>

int main(){
	int i,j;
	int niz[5] = {3, 1, 2, 5, 4};
	for(i=0;i<4;i++){
		for(j=i+1; j<5;j++){
			if(niz[i]>niz[j]){
				int t = niz[j];
				niz[j] = niz[i];
				niz[i] = t;
			}
		}
	}
//	printf("%d",min);

	for(i=0;i<5;i++){
		printf("%d\n",niz[i]);
	}


}
