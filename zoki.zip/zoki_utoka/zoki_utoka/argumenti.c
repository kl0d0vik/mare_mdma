#include <stdio.h>

int main(int brArg, char *arg[]){

	int i;

	printf("Broj argumenata je %d\n\n",brArg);

	for(i=0;i<brArg;i++){
		puts(arg[i]);
	}

	return 0;

}
