

#include <stdio.h>

int prost(int);


int main(){
	int m;
	int n;
	scanf("%d", &n);



	for(m=1;m<n;m++){
		if(prost(m)){
			printf("%d je prost broj\n",m);
		}
		else{
			continue;
		}
	}
}
int prost(int x){

	int i;
	for(i=2;i<=x-1;i++){
		if(x%i == 0){
			break;
			return x;
		}
		else{
			continue;
		}
	}
}
