#include <stdio.h>

int main(){

       int x = 6;

       int i;
       for(i=2;i<=x-1;i++){
                if(x%i == 0){
			printf("%d nije prost \n",x);
			break;
                }
                else{
                        continue;
                }
        }
}

