#include <stdio.h>
#include <string.h>

int main(){

	static char ime[] = "Bingo";
	char *pok;
	pok = ime + strlen(ime);
	puts(pok);
	while(--pok>=ime)
		puts(pok);

}
