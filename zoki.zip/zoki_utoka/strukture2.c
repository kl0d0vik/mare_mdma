#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#define MAX 30

struct tacka{
	float x;
	float y;
};

int najbliza(struct tacka t[], int n);
float udaljenost(struct tacka);

int main(){

	struct tacka t[MAX];
	int i;
	int n;
	int data;
	do{
		printf("klk tacaka oces da uneses klosaru : ");
		scanf("%d",&n);
	}while(n<=0 || n>30);

	for(i=0;i<n;i++){
		printf("Unesi koordinate %d tacke: ", i);
		scanf("%f %f", &t[i].x, &t[i].y);
	}

	data = najbliza(t,n);
	printf("Najbliza je %d tacka ", data);
	printf("%f %f\n", t[data].x, t[data].y);

}
float udaljenost(struct tacka t1){
		return sqrt(pow(t1.x,2)+pow(t1.y,2));
}



int najbliza(struct tacka t[],int n){
	int i;
	double min;
	int index=0;
	min = udaljenost(t[0]);
	for(i=0;i<n;i++){
		if(udaljenost(t[i])<min){
			min = udaljenost(t[i]);
			index = i;
		}
		else{
			continue;
		}
	}
	printf("%d",index);
	return index;
}








