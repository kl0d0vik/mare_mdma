#include <stdio.h>
#include <string.h>

int main(){

	char *pok;

	pok = "Tango";
	puts(pok);
	puts(++pok);
	puts(++pok);

}
