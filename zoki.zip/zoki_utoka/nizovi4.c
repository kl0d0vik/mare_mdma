#include <stdio.h>
#define MAX_SIZE 25

int main(){

	int n,i,j=0,m=0;
	int X[MAX_SIZE],A[MAX_SIZE],B[MAX_SIZE];

	do{
		printf("unesi klk clanova - n : ");
		scanf("%d",&n);
	}while(n <=0 || n>MAX_SIZE);

	for(i=0;i<MAX_SIZE;i++){
		X[i]=0;
		A[i]=0;
		B[i]=0;
	}

	for(i=0;i<n;i++){
		printf("X[%d] = ",i);
		scanf("%d", &X[i]);
	}
	printf("\n");
	for(i=0;i<n;i++){
		if(X[i]%2 == 0){
			A[j] = X[i];
			j++;
		}
		else{
			continue;
		}
	}
	for(i=0;i<n;i++){
		 if(X[i] < 0){
			B[m] = X[i];
			m++;
		}
		else{
			continue;
		}
	}
	for(i=0;i<n;i++){
		printf("X[%d] = %d\n",i, X[i]);
	}
	for(i=0;i<j;i++){
		printf("A[%d] = %d\n",i,A[i]);
	}
	for(i=0;i<m;i++){
		printf("B[%d] = %d\n",i,B[i]);
	}


	return 0;

}
