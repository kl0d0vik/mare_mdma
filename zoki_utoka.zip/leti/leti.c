#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define MAX_CHAR 20+1
#define MAX_NIZ 30

struct prevoznik_st{
	char naziv_operatora[MAX_CHAR];
	double cena_karte;
	double maks_prtljag;
	double prtljag_po_kg;
};
struct cena_st{
	double cena_prevoza;
	char naziv_operatora[MAX_CHAR];
};

FILE *safe_fopen(char filename[],char mode[], int error_code);
void ucitaj(FILE *in, struct prevoznik_st prevoznik[], int *n);
void transform(struct prevoznik_st prevoznik[], struct cena_st cena[], int n, double kg);
void ispis(FILE *out, struct cena_st cena[], int n);

int main(int brojArg, char **args){
	if(brojArg!=4){
		printf("Pusi kurac klosaru\n");
	}

	double kg = atoi(args[1]);
	char *input_filename = args[2];
	char *output_filename = args[3];

	FILE *in = safe_fopen(input_filename,"r",1);
	FILE *out = safe_fopen(output_filename, "w", 2);

	struct  prevoznik_st prevoznik[MAX_NIZ];
	struct cena_st cena[MAX_NIZ];
	int n=0;

	ucitaj(in,prevoznik,&n);
	transform(prevoznik,cena, n, kg);
	ispis(out, cena, n);

	fclose(in);
	fclose(out);

	return 0;
}

FILE *safe_fopen(char filename[],char mode[], int error_code){
	FILE *fp = fopen(filename, mode);
	if(fp==NULL){
		printf("Fajl ne postoji\n");
		exit(error_code);
	}
}

void ucitaj(FILE *in, struct prevoznik_st prevoznik[], int *n){
	*n = 0;
	while(fscanf(in, "%s %lf %lf %lf",
		prevoznik[*n].naziv_operatora,
		&prevoznik[*n].cena_karte,
		&prevoznik[*n].maks_prtljag,
		&prevoznik[*n].prtljag_po_kg
	)!=EOF){
		(*n)++;
	}
}
void transform(struct prevoznik_st prevoznik[], struct cena_st cena[], int n, double kg){
		int i;
		for(i=0;i<n;i++){
			strcpy(cena[i].naziv_operatora,prevoznik[i].naziv_operatora);
			if(kg > prevoznik[i].maks_prtljag){
				cena[i].cena_prevoza = prevoznik[i].cena_karte + (kg - prevoznik[i].maks_prtljag)*prevoznik[i].prtljag_po_kg;
			}
			else{
				cena[i].cena_prevoza = prevoznik[i].cena_karte;
			}
		}
}
void ispis(FILE *out, struct cena_st cena[], int n){
	int i;
	for(i=0;i<n;i++){
		fprintf(out,"%f %s\n",cena[i].cena_prevoza,cena[i].naziv_operatora);
	}
}
