#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#define MAX_CHAR 20+1
#define MAX_NIZ 30

struct paket_st{
	char zemlja[MAX_CHAR];
	char naziv_operatora[MAX_CHAR];
	double mesecna_pretplata;
	double broj_kwh_u_pretplati;
	double cena_po_kwh;
};

struct cena_st{
	double ukupna_cena;
	char zemlja[MAX_CHAR];
	char naziv_operatora[MAX_CHAR];
};

FILE *safe_fopen(char filename[], char mode[], int error_code);
void ucitaj(FILE *in, struct paket_st paketi[], int *n);
void transform(struct paket_st paketi[], struct cena_st cena[], int n, int potroseno_kwh);
void ispisi(FILE *out, struct cena_st cena[], int n);

int main(int brArg, char **args){

	if(brArg!=4){
		printf("Usage : %s [potroseno_kwh] [ulazna-datoteka] [izlazna-datoteka]\n", args[0]);
		exit(1);
	}

	int potroseno_kwh = atoi(args[1]);
	char *input_filename = args[2];
	char *output_filename = args[3];

	FILE *in = safe_fopen(input_filename, "r", 1);
	FILE *out = safe_fopen(output_filename, "w", 2);

	struct paket_st paketi[MAX_NIZ];
	struct cena_st cena[MAX_NIZ];
	int n;


	ucitaj(in, paketi, &n);
	transform(paketi, cena, n, potroseno_kwh);
	ispisi(out, cena, n);

	fclose(in);
	fclose(out);
}

FILE *safe_fopen(char filename[], char mode[], int error_code){
	FILE *fp = fopen(filename, mode);
	if(fp==NULL){
		printf("Ne postoji fajl ili nesto\n");
		exit(error_code);
	}
	return fp;
}

void ucitaj(FILE *in, struct paket_st paketi[], int *n){
	*n = 0;
	while(fscanf(in, "%s %s  %lf %lf %lf",
		paketi[*n].zemlja,
		paketi[*n].naziv_operatora,
		&paketi[*n].mesecna_pretplata,
		&paketi[*n].broj_kwh_u_pretplati,
		&paketi[*n].cena_po_kwh
	)!=EOF){
		(*n)++;
	}
}

void transform(struct paket_st paketi[], struct cena_st cena[], int n, int potroseno_kwh){
	int i;
	for(i=0;i<n;i++){
		strcpy(cena[i].zemlja,paketi[i].zemlja);
		strcpy(cena[i].naziv_operatora,paketi[i].naziv_operatora);
		if(potroseno_kwh > paketi[i].broj_kwh_u_pretplati){
			cena[i].ukupna_cena = paketi[i].mesecna_pretplata + (potroseno_kwh - paketi[i].broj_kwh_u_pretplati)*paketi[i].cena_po_kwh;
		}
		else{
			cena[i].ukupna_cena = paketi[i].mesecna_pretplata;
		}
	}
}

void ispisi(FILE *out, struct cena_st cena[], int n){
	int i;
	for(i=0;i<n;i++){
		fprintf(out,"%7.2f %s %s\n",
			cena[i].ukupna_cena,
			cena[i].zemlja,
			cena[i].naziv_operatora);
	}
}
