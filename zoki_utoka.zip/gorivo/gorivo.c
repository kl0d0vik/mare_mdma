#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_OZNAKA 2+1
#define MAX_GORIVO 10+1
#define MAX_NIZ 30

struct gorivo_st{
	char oznaka_grada[MAX_OZNAKA];
	char tip_goriva[MAX_GORIVO];
	float cena;
};
struct analiza_st{
	double nova_cena;
	double procenat_uvecanja;
	char oznaka_grada[MAX_OZNAKA];
	char tip_goriva[MAX_GORIVO];
};


FILE *milentije(char filename[], char mode[], int error);
void ulaz(FILE *in,struct gorivo_st gorivo[],int *n);
void obrada(struct gorivo_st gorivo[], struct analiza_st analiza[], int n,float akciza);
void izlaz (FILE *out, struct analiza_st analiza[],int n);

int main(int br_arg,char  **arg){
	if(br_arg!=4){
		printf("Greska");
		exit(1);
}

float  akciza=atof(arg[1]);
char *input=arg[2];
char *output=arg[3];

int n;
struct gorivo_st gorivo[MAX_NIZ];
struct analiza_st analiza[MAX_NIZ];

FILE *in=milentije(input, "r",1);
FILE *out=milentije(output, "w",2);

ulaz(in,gorivo,&n);
obrada(gorivo,analiza,n,akciza);
izlaz(out,analiza,n);

fclose(in);
fclose(out);

return 0;
}

FILE *milentije(char filename[], char mode[], int error){
FILE *m=fopen(filename,mode);
	if(m==NULL){
		printf("Greska");
exit(error);
}
return m;
}
void ulaz(FILE *in,struct gorivo_st gorivo[],int *n){
	*n=0;
	while(fscanf(in,"%s %s %f",gorivo[*n].oznaka_grada, gorivo[*n].tip_goriva,&gorivo[*n].cena)!=EOF){
		(*n)++;
}
}
void obrada(struct gorivo_st gorivo[], struct analiza_st analiza[], int n,float akciza){
	int i;
	for(i=0;i<n;i++){
		strcpy(analiza[i].oznaka_grada, gorivo[i].oznaka_grada);
		strcpy(analiza[i].tip_goriva, gorivo[i].tip_goriva);
		analiza[i].nova_cena = gorivo[i].cena + akciza;
		analiza[i].procenat_uvecanja = (analiza[i].nova_cena / gorivo[i].cena) * 100 - 100;
	}
}
void izlaz (FILE *out, struct analiza_st analiza[],int n){
	int i;
	for(i=0;i<n;i++){
		fprintf(out, "%6.2f %5.2f %s %s\n",analiza[i].nova_cena,analiza[i].procenat_uvecanja,analiza[i].oznaka_grada, analiza[i].tip_goriva);
	}
}

























