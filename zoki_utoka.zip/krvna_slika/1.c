#include <stdio.h>
#include <string.h>


int main(int brA, char **args){


	printf("%s\n", args[1]);
	char *aa = args[1];
	if(strcmp("a",aa)==0){
		printf("AAAAAAA");
	}

}
