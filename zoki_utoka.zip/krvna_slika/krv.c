#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define MAX_CHAR 20+1
#define MAX_NIZ 30
#define UPOZ 1+1

struct pacijenti_st{
	char ime[MAX_CHAR];
	char prezime[MAX_CHAR];
	double holesterol;
	unsigned krvni_pritisak;
	double secer;
};

struct analiza_st{
	char znak[UPOZ];
	char ime[MAX_CHAR];
	char prezime[MAX_CHAR];
};
FILE *safe_fopen(char filename[], char mode[], int error_code);
void ucitaj(FILE *in, struct pacijenti_st pacijenti[], int *n);
void transform(struct pacijenti_st pacijenti[], struct analiza_st analiza[], int n, char opcija[]);
void ispisi(FILE *out, struct analiza_st analiza[], int n);

int main(int brArg, char **args){
	if(brArg!=4){
		printf("koristenje : %s [opcije] [ulazni-fajl] [izlazni-fajl]\n", args[0]);
		printf("opcije : pritisak, holesterol i secer\n");
		exit(1);
	}

	char *opcija = args[1];
	char *input_filename = args[2];
	char *output_filename = args[3];

	FILE *in = safe_fopen(input_filename, "r", 1);
	FILE *out = safe_fopen(output_filename, "w", 2);

	struct pacijenti_st pacijenti[MAX_NIZ];
	struct analiza_st analiza[MAX_NIZ];
	int n;

	ucitaj(in, pacijenti, &n);
	transform(pacijenti, analiza, n, opcija);
	ispisi(out, analiza, n);
	printf("%s",opcija);
	fclose(in);
	fclose(out);

	return 0;

}
FILE *safe_fopen(char filename[], char mode[], int error_code){
	FILE *fp = fopen(filename, mode);
	if(fp==NULL){
		printf("Problem sa fajlom\n");
		exit(error_code);
	}
}

void ucitaj(FILE *in, struct pacijenti_st pacijenti[], int *n){
	*n = 0;
	while(fscanf(in, "%s %s %lf %u %lf",
		pacijenti[*n].ime,
		pacijenti[*n].prezime,
		&pacijenti[*n].holesterol,
		&pacijenti[*n].krvni_pritisak,
		&pacijenti[*n].secer
	)!=EOF){
		(*n)++;
	}
}

void transform(struct pacijenti_st pacijenti[], struct analiza_st analiza[], int n, char opcija[]){
	int i;
	for(i=0;i<n;i++){
		strcpy(analiza[i].ime, pacijenti[i].ime);
		strcpy(analiza[i].prezime, pacijenti[i].prezime);
	}
}

void ispisi(FILE *out, struct analiza_st analiza[], int n){
	int i;
	for(i=0;i<n;i++){
		fprintf(out,"%s %s %s",
			analiza[i].znak,
			analiza[i].ime,
			analiza[i].prezime);
	}
}

