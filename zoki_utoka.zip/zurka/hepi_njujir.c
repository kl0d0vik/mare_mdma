#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define MAX_CHAR 20
#define MAX_NIZ 30

struct zelja_st{
	unsigned broj_gostiju;
	char naziv_pizze[MAX_CHAR];
};
struct porudzbina_st{
	double potrebno_parcadi;
	unsigned potrebne_cele_pizze;
	char naziv_pizze[MAX_CHAR];
};

FILE *safe_fopen(char filename[], char mode[], int error_code);
void ucitaj(FILE *in, struct zelja_st zelje[], int *n);
void transform(struct zelja_st zelje[], struct porudzbina_st porudzbina[], int n, double apetit);
void ispisi(FILE *out, struct porudzbina_st porudzbina[], int n);

int main(int brArg, char **args){

	if(brArg!=4){
		printf("usage: %s [apetit] [ulazna-datoteka] [izlazna-datoteka]");
		exit(1);
	}

	double apetit = atof(args[1]);
	char *input_filename = args[2];
	char *output_filename = args[3];
	int n;

	FILE *in = safe_fopen(input_filename, "r", 1);
	FILE *out = safe_fopen(output_filename, "w",2);

	struct zelja_st zelje[MAX_NIZ];
	struct porudzbina_st porudzbina[MAX_NIZ];

	ucitaj(in, zelje, &n);
	transform(zelje, porudzbina ,n,apetit);
	ispisi(out, porudzbina, n);

	fclose(in);
	fclose(out);

//	printf("%lf", 40*2.5);

}

FILE *safe_fopen(char filename[], char mode[], int error_code){
	FILE *fn = fopen(filename, mode);
	if(fn==NULL){
		printf("Problem sa fajlom\n");
		exit(error_code);
	}
}

void ucitaj(FILE *in, struct zelja_st zelje[], int *n){
	*n = 0;
	while(fscanf(in,"%u %s",
		&zelje[*n].broj_gostiju,
		zelje[*n].naziv_pizze
	)!=EOF){
		(*n)++;
	}
}

void transform(struct zelja_st zelje[], struct porudzbina_st porudzbina[], int n, double apetit){
	int i;
	for(i=0;i<n;i++){
		strcpy(porudzbina[i].naziv_pizze, zelje[i].naziv_pizze);
		porudzbina[i].potrebno_parcadi = zelje[i].broj_gostiju * apetit;
		porudzbina[i].potrebne_cele_pizze = ceil(porudzbina[i].potrebno_parcadi / 8);
	}
}

void ispisi(FILE *out, struct porudzbina_st porudzbina[], int n){
	int i;
	for(i=0;i<n;i++){
		fprintf(out,"%5.1lf %2u %s\n",
			porudzbina[i].potrebno_parcadi,
			porudzbina[i].potrebne_cele_pizze,
			porudzbina[i].naziv_pizze);
	}
}

